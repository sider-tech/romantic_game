import HeartCatcherGame from "../heart-catcher-game"

export default function Page() {
  return <HeartCatcherGame />
}
